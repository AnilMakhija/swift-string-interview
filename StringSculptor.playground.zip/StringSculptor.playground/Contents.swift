import UIKit

//var greeting = "Hello, playground"

//How do you reverse a given string in place?
func reverseStrig(_str:String) -> String{
    let str = String(_str.reversed())
    return str
}

let myString = reverseStrig(_str: "Anil")
print(myString)


//How do you print duplicate characters from a string?
func printDuplicateCharacters(from string: String) {
    var characterCount:[Character:Int] = [:]
    
    
    for character in string {
        characterCount[character, default: 0] += 1
    }
    
    print("Duplicate Characters")
    for (chaeacter, count) in characterCount {
        if count > 1 {
            
        }
    }
}
let inputString = "programming"
printDuplicateCharacters(from: inputString)


//How do you check if two strings are anagrams of each other
func anagramsTwoString(str1:String, str2:String) -> Bool{
    
    //remove whitespace and convert lowercase
    let cleanedA = str1.replacingOccurrences(of: " ", with: "").lowercased()
    let cleanedB = str2.replacingOccurrences(of: " ", with: "").lowercased()
    
    guard cleanedA.count == cleanedB.count else {return false}

    let sortedA = cleanedA.sorted()
    let sortedB = cleanedB.sorted()
    
    return sortedA == sortedB
    
}

let stringA = "Listen"
let stringB = "Silent"
let result = anagramsTwoString(str1: stringA, str2: stringB)
print(result)


//How do you reverse words in a given sentence
func reverseWords(in str:String) ->String{
    
    //split sentence in to words by whitespace
    let words = str.split(separator: " ").map(String.init)
    print("words",words)
    
    //revers the order word
    let reverceWords = words.reversed()

    //Join revers words in to string
    let revercedSentence = reverceWords.joined(separator: " ")
    
    return revercedSentence
    
}

let inputsentence = "Hello world this is swift"
let reveredSentence = reverseWords(in: inputsentence)
print(reveredSentence)


let str = inputsentence.split(separator: " ").map(String.init)
let reverce = str.reversed()
let addspace = reverce.joined(separator: " ")
print(addspace)


//How do you check if a given string is a palindrome
func palindrome(_ str:String) -> Bool {
    return String(str.reversed()) == str
}

let inputString = palindrome("anana")
print(inputString)

//how do remove the duplicate character from String?
func duplicateChar(_ str:String) -> String {
    var seenCharacter: Set<Character> = []
    var result = ""
    
    let sentanc = str.replacingOccurrences(of: " ", with: "")
    for char in sentanc {
        if !seenCharacter.contains(char){
            seenCharacter.insert(char)
            result.append(char)
        }
    }
    return result
}
let inputSentence = "Hello how are you"
let result = duplicateChar(inputSentence)
print(result)


////How do you remove a given character from a String?
func removeGivenChar(from str:String, char:Character) -> String {
    let result = str.filter { $0 != char}
    return result
}

//Example
let input = "Hello world!"
let characterRemove:Character = "l"
let output = removeGivenChar(from: input, char: characterRemove)
print(output)
